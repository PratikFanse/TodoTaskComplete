export class Task {
    constructor(
    public taskid:number,
    public task:string,
    public status:string,
    public userid:number
    ){}
}
