export class UserLog{
    constructor(public date:string, public count:number){}
}