import { Component, OnInit } from '@angular/core';
import { UserLog } from './data/UserLog.model';
import { GraphData } from './data/GraphData.model';
import { GraphService } from './graph.service';

@Component({
  selector: 'app-graph',
  templateUrl: './graph.component.html',
  styleUrls: ['./graph.component.css']
})
export class GraphComponent implements OnInit {
  userLog:UserLog[];
  regCountPer=0;
  taksCount=0;
  activeCount=0;
  graphData:GraphData[];
  changeGraph='new';

  constructor(private graphService:GraphService) { }

  ngOnInit(): void {
  this.graphService.getGraphDetails().then(
    data => {this.graphData= data;
      for(let i=0; i<=data.length-1;i++){
      this.regCountPer += data[i].regcount;
      this.taksCount+=data[i].taskcount;
    }
    }
  )
  this.graphService.getUserLog().then(
    data=>{ this.userLog=data
    for(let i=0; i<=data.length-1;i++){
      console.log(data[0].date)
    this.activeCount += data[i].count;
  }}
  )
  }
  
  getPercent(per:number,total:number){
   return per/total*100; 
  }


 
}
