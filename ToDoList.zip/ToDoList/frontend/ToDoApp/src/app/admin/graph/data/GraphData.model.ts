export class GraphData{
    constructor(public id:number,public date:string, public regcount:number, public taskcount){}
}